<!-- Cuplikan Layout HTML -->
<div class="product-detail" style="display: flex; gap: 40px; padding: 50px;">
    <div class="foto" style="flex: 1;">
        <img src="image/produk/aeris_soap_fine_linen.jpg" style="width: 100%;">
    </div>
    <div class="info" style="flex: 1;">
        <h1>Aeris Beaute Blendie Bar Soap</h1>
        <h2 style="color: #666;">Varian: Fine Linen</h2>
        <h3 class="price">Rp 55.000</h3>
        
        <p><strong>Ukuran Isi:</strong> 35 gr | <strong>Kategori Aroma:</strong> Fresh</p>
        <p><strong>Deskripsi:</strong> Sabun batang Aeris Beaute varian Fine Linen dengan aroma kain bersih yang segar dan mewah. Formulasi pelembab alami menjaga kelembaban kulit sepanjang hari.</p> <!--[cite: 4] -->
        
        <form action="keranjang.php" method="POST">
            <input type="hidden" name="id_produk" value="1">
            <label>Jumlah:</label>
            <input type="number" name="qty" value="1" min="1" max="50" style="padding: 10px; width: 60px;">
            <button type="submit" class="btn-shop" style="margin-left: 10px;">ADD TO BAG</button>
        </form>
    </div>
</div>