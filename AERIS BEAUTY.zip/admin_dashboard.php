<?php 
require 'koneksi.php'; 
// Validasi peran admin
if(!isset($_SESSION['peran']) || $_SESSION['peran'] == 'pelanggan') { die("Akses Ditolak"); }
?>
<div style="display: flex;">
    <!-- Sidebar Admin -->
    <div style="width: 250px; background: #222; color: white; height: 100vh; padding: 20px;">
        <h2>AERIS ERP</h2>
        <ul style="list-style: none; padding: 0;">
            <li><a href="admin_dashboard.php" style="color:white; text-decoration:none;">📊 Dashboard</a></li>
            <li><a href="crud_produk.php" style="color:white; text-decoration:none;">🛍️ Master Produk</a></li>
            <li><a href="inventory.php" style="color:white; text-decoration:none;">📦 Warehouse / Stok</a></li>
            <li><a href="finance.php" style="color:white; text-decoration:none;">💰 Finance & Jurnal</a></li>
            <li><a href="sdm.php" style="color:white; text-decoration:none;">👥 SDM & Karyawan</a></li>
            <li><a href="pesanan_admin.php" style="color:white; text-decoration:none;">🚚 Pesanan</a></li>
        </ul>
    </div>

    <!-- Konten Dashboard -->
    <div style="flex: 1; padding: 30px; background: #f9f9f9;">
        <h2>Ringkasan Operasional Hari Ini</h2>
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px;">
            
            <!-- Laporan Omset dari tabel pesanan[cite: 4] -->
            <?php 
            $q_omset = mysqli_query($conn, "SELECT SUM(total_bayar) as omset FROM pesanan WHERE status_pembayaran='lunas'");
            $omset = mysqli_fetch_assoc($q_omset)['omset'];
            ?>
            <div style="background: white; padding: 20px; border-left: 5px solid green;">
                <h3>Total Omset</h3>
                <p style="font-size: 24px; font-weight: bold;">Rp <?= number_format($omset,0,',','.') ?></p>
            </div>

            <!-- Pesanan Menunggu -->
            <?php 
            $q_pesanan = mysqli_query($conn, "SELECT COUNT(*) as jml FROM pesanan WHERE status_pesanan='menunggu_pembayaran'");
            $pesanan = mysqli_fetch_assoc($q_pesanan)['jml'];
            ?>
            <div style="background: white; padding: 20px; border-left: 5px solid orange;">
                <h3>Pesanan Menunggu</h3>
                <p style="font-size: 24px; font-weight: bold;"><?= $pesanan ?> Transaksi</p>
            </div>

            <!-- Stok Kritis Peringatan[cite: 4] -->
            <?php 
            $q_stok = mysqli_query($conn, "SELECT COUNT(*) as kritis FROM produk WHERE stok <= stok_minimum");
            $stok = mysqli_fetch_assoc($q_stok)['kritis'];
            ?>
            <div style="background: white; padding: 20px; border-left: 5px solid red;">
                <h3>Peringatan Stok Kritis</h3>
                <p style="font-size: 24px; font-weight: bold;"><?= $stok ?> Produk Butuh Restock</p>
            </div>
        </div>
    </div>
</div>