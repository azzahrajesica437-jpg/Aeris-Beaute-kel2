<form method="POST" action="proses_checkout.php">
    <h3>Pilih Metode Pembayaran</h3>
    <select name="metode_pembayaran" style="padding: 10px; width: 100%;">
        <option value="transfer_bank">Transfer Bank (BCA / Mandiri)</option> <!--[cite: 4] -->
        <option value="qris">QRIS (Scan Barcode)</option>
        <option value="cod">Cash on Delivery (COD)</option>
    </select>
    
    <h3>Jasa Pengiriman</h3>
    <select name="kurir" style="padding: 10px; width: 100%;">
        <option value="JNE Regular">JNE Regular</option> <!--[cite: 4] -->
        <option value="J&T Express">J&T Express</option>
        <option value="SiCepat BEST">SiCepat BEST</option>
    </select>
    
    <button type="submit" class="btn-shop" style="width: 100%; margin-top: 20px;">BUAT PESANAN</button>
</form>