-- ============================================================
-- SKRIP BASIS DATA LENGKAP: E-COMMERCE KOSMETIK TERINTEGRASI MODEL ERP
-- Brand          : Aeris Beaute
-- Program Studi  : Sistem Informasi / Teknik Informatika
-- Modul          : Aplikasi Web PHP Native MVC Murni
-- Database       : db_aeris_beaute
-- Dibuat dari    : database_aeris_beaute.xlsx (Jakarta Timur, Indonesia)
-- ============================================================

-- 1. Buat Basis Data jika belum ada
CREATE DATABASE IF NOT EXISTS `db_aeris_beaute`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE `db_aeris_beaute`;

-- Nonaktifkan pengecekan foreign key sementara
SET FOREIGN_KEY_CHECKS = 0;

-- Hapus tabel lama jika ada (urutan drop yang aman)
DROP TABLE IF EXISTS `jurnal_keuangan`;
DROP TABLE IF EXISTS `akun_rekening`;
DROP TABLE IF EXISTS `mutasi_stok`;
DROP TABLE IF EXISTS `detail_pesanan`;
DROP TABLE IF EXISTS `pesanan`;
DROP TABLE IF EXISTS `produk`;
DROP TABLE IF EXISTS `kategori`;
DROP TABLE IF EXISTS `pengguna`;

-- ============================================================
-- TABEL 1: PENGGUNA (Master Akun & Hak Akses)
-- Peran:
-- - 'superadmin' : Akses penuh ke seluruh modul ERP
-- - 'gudang'     : Kelola stok masuk, opname, dan katalog produk
-- - 'kasir'      : Proses pesanan dan verifikasi pembayaran
-- - 'pelanggan'  : Transaksi belanja di front-end toko
-- ============================================================

CREATE TABLE `pengguna` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `nama_lengkap`   VARCHAR(100) NOT NULL    COMMENT 'Nama lengkap pemilik akun',
  `email`          VARCHAR(100) NOT NULL UNIQUE COMMENT 'Email aktif untuk login',
  `kata_sandi`     VARCHAR(255) NOT NULL    COMMENT 'Password dienkripsi dengan password_hash()',
  `no_telp`        VARCHAR(20)  DEFAULT NULL COMMENT 'Nomor kontak WhatsApp / HP',
  `alamat`         TEXT         DEFAULT NULL COMMENT 'Alamat lengkap pengiriman atau tempat tinggal',
  `peran`          ENUM('superadmin','gudang','kasir','pelanggan') NOT NULL DEFAULT 'pelanggan'
                   COMMENT 'Hak akses dalam sistem',
  `status_aktif`   TINYINT(1)   NOT NULL DEFAULT 1 COMMENT '1 = Aktif, 0 = Diblokir/Nonaktif',
  `dibuat_pada`    DATETIME     DEFAULT CURRENT_TIMESTAMP,
  `diperbarui_pada` DATETIME    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Tabel data pengguna dan hak akses ERP';

-- ============================================================
-- TABEL 2: KATEGORI (Master Kategori Produk Aeris Beaute)
-- ============================================================

CREATE TABLE `kategori` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `nama_kategori`  VARCHAR(100) NOT NULL    COMMENT 'Nama kategori produk (Bar Soap, Brush Set, Makeup Bag)',
  `slug`           VARCHAR(120) NOT NULL UNIQUE COMMENT 'Slug ramah URL',
  `deskripsi`      TEXT         DEFAULT NULL COMMENT 'Penjelasan singkat kategori produk',
  `dibuat_pada`    DATETIME     DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Master Kategori Produk Aeris Beaute';

-- ============================================================
-- TABEL 3: PRODUK (Master Data Produk & Persediaan)
-- Disesuaikan untuk produk kecantikan Aeris Beaute.
-- Kolom tambahan: nama_varian, kategori_aroma, ukuran_isi,
--                 asal_produk, dikirim_dari, jumlah_per_kemasan.
-- ============================================================

CREATE TABLE `produk` (
  `id`                  INT AUTO_INCREMENT PRIMARY KEY,
  `kategori_id`         INT          NOT NULL  COMMENT 'Relasi ke tabel kategori',
  `kode_produk`         VARCHAR(20)  NOT NULL UNIQUE COMMENT 'Kode unik produk (format: AB001 dst)',
  `nama_produk`         VARCHAR(150) NOT NULL  COMMENT 'Nama lini produk Aeris Beaute',
  `nama_varian`         VARCHAR(150) NOT NULL  COMMENT 'Nama varian spesifik (misal: Fine Linen, The Onyx 2.0)',
  `slug`                VARCHAR(200) NOT NULL UNIQUE COMMENT 'Slug untuk URL detail produk',
  `deskripsi`           TEXT         DEFAULT NULL COMMENT 'Deskripsi detail produk',
  `kategori_aroma`      ENUM('Fresh','Sweet','Floral','-') NOT NULL DEFAULT '-'
                        COMMENT 'Kategori aroma khusus Bar Soap; (-) untuk produk lain',
  `ukuran_isi`          VARCHAR(20)  NOT NULL DEFAULT '-'
                        COMMENT 'Berat/jumlah isi (contoh: 35 gr, 15 pcs)',
  `asal_produk`         VARCHAR(50)  NOT NULL DEFAULT 'Indonesia'
                        COMMENT 'Negara asal produksi',
  `dikirim_dari`        VARCHAR(100) NOT NULL DEFAULT 'Jakarta Timur'
                        COMMENT 'Kota asal pengiriman',
  `jumlah_per_kemasan`  INT          NOT NULL DEFAULT 1
                        COMMENT 'Jumlah item dalam satu kemasan',
  `harga_beli`          DECIMAL(12,2) NOT NULL DEFAULT 0.00
                        COMMENT 'HPP (Harga Pokok Pembelian) satuan saat restock',
  `harga_jual`          DECIMAL(12,2) NOT NULL DEFAULT 0.00
                        COMMENT 'Harga jual ke konsumen e-commerce',
  `stok`                INT          NOT NULL DEFAULT 0 COMMENT 'Jumlah stok fisik saat ini',
  `stok_minimum`        INT          NOT NULL DEFAULT 10
                        COMMENT 'Batas peringatan stok menipis pada dashboard ERP',
  `berat_gram`          INT          NOT NULL DEFAULT 200
                        COMMENT 'Berat produk dalam gram untuk kalkulasi ongkir',
  `gambar`              VARCHAR(255) DEFAULT 'default_produk.jpg' COMMENT 'Nama file foto produk',
  `status`              ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif'
                        COMMENT 'Status tayang di katalog toko',
  `dibuat_pada`         DATETIME     DEFAULT CURRENT_TIMESTAMP,
  `diperbarui_pada`     DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_produk_kategori`
    FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Master Data Produk dan Persediaan Aeris Beaute';

-- ============================================================
-- TABEL 4: PESANAN (Header Transaksi Penjualan E-Commerce)
-- ============================================================

CREATE TABLE `pesanan` (
  `id`                  INT AUTO_INCREMENT PRIMARY KEY,
  `no_pesanan`          VARCHAR(40)  NOT NULL UNIQUE
                        COMMENT 'Nomor unik transaksi (contoh: ORD-20260912-001)',
  `pengguna_id`         INT          NOT NULL COMMENT 'ID pelanggan yang berbelanja',
  `tanggal_pesanan`     DATETIME     DEFAULT CURRENT_TIMESTAMP COMMENT 'Waktu checkout dilakukan',
  `total_belanja`       DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT 'Subtotal harga produk',
  `ongkir`              DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT 'Biaya pengiriman kurir',
  `total_bayar`         DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT 'Total belanja + ongkir',
  `status_pesanan`      ENUM('menunggu_pembayaran','diproses','dikirim','selesai','dibatalkan')
                        NOT NULL DEFAULT 'menunggu_pembayaran' COMMENT 'Status alur pesanan',
  `status_pembayaran`   ENUM('belum_lunas','lunas') NOT NULL DEFAULT 'belum_lunas'
                        COMMENT 'Status finansial pesanan',
  `metode_pembayaran`   ENUM('transfer_bank','cod') NOT NULL DEFAULT 'transfer_bank'
                        COMMENT 'Metode pembayaran yang dipilih',
  `kurir`               VARCHAR(50)  NOT NULL DEFAULT 'JNE Regular'
                        COMMENT 'Ekspedisi pengiriman (JNE, J&T, SiCepat, dll)',
  `nomor_resi`          VARCHAR(50)  DEFAULT NULL COMMENT 'Nomor resi paket dari ekspedisi',
  `nama_penerima`       VARCHAR(100) NOT NULL COMMENT 'Nama tujuan kirim',
  `no_telp_penerima`    VARCHAR(20)  NOT NULL COMMENT 'Nomor telepon tujuan',
  `alamat_pengiriman`   TEXT         NOT NULL COMMENT 'Alamat tujuan lengkap',
  `catatan`             TEXT         DEFAULT NULL COMMENT 'Catatan tambahan dari pembeli',
  `bukti_transfer`      VARCHAR(255) DEFAULT NULL COMMENT 'File upload bukti transfer bank',
  `dibuat_pada`         DATETIME     DEFAULT CURRENT_TIMESTAMP,
  `diperbarui_pada`     DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_pesanan_pengguna`
    FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Header Transaksi Pesanan Penjualan Aeris Beaute';

-- ============================================================
-- TABEL 5: DETAIL_PESANAN (Rincian Item yang Dipesan)
-- ============================================================

CREATE TABLE `detail_pesanan` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `pesanan_id`      INT           NOT NULL COMMENT 'Relasi ke tabel pesanan',
  `produk_id`       INT           NOT NULL COMMENT 'Relasi ke tabel produk',
  `nama_varian`     VARCHAR(150)  NOT NULL COMMENT 'Snapshot nama varian saat transaksi',
  `kuantitas`       INT           NOT NULL DEFAULT 1 COMMENT 'Jumlah item yang dibeli',
  `harga_satuan`    DECIMAL(12,2) NOT NULL DEFAULT 0.00
                    COMMENT 'Harga jual satuan saat transaksi',
  `hpp_satuan`      DECIMAL(12,2) NOT NULL DEFAULT 0.00
                    COMMENT 'HPP satuan saat transaksi (untuk kalkulasi Laba/Rugi)',
  `subtotal`        DECIMAL(12,2) NOT NULL DEFAULT 0.00
                    COMMENT 'kuantitas * harga_satuan',
  CONSTRAINT `fk_detail_pesanan`
    FOREIGN KEY (`pesanan_id`) REFERENCES `pesanan` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_detail_produk`
    FOREIGN KEY (`produk_id`) REFERENCES `produk` (`id`)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Detail Item Produk per Pesanan Aeris Beaute';

-- ============================================================
-- TABEL 6: MUTASI_STOK (Kartu Stok & Audit Trail Inventaris)
-- ============================================================

CREATE TABLE `mutasi_stok` (
  `id`               INT AUTO_INCREMENT PRIMARY KEY,
  `produk_id`        INT          NOT NULL COMMENT 'ID produk yang termutasi',
  `jenis_mutasi`     ENUM('masuk_restock','keluar_penjualan','penyesuaian_opname','retur_masuk')
                     NOT NULL COMMENT 'Jenis perubahan stok',
  `jumlah`           INT          NOT NULL COMMENT 'Banyaknya barang yang berubah',
  `stok_sebelum`     INT          NOT NULL COMMENT 'Jumlah stok sebelum aksi',
  `stok_sesudah`     INT          NOT NULL COMMENT 'Jumlah stok setelah aksi',
  `nomor_referensi`  VARCHAR(50)  DEFAULT NULL COMMENT 'Nomor Pesanan atau No Faktur Supplier',
  `keterangan`       TEXT         DEFAULT NULL COMMENT 'Catatan alasan mutasi atau nama supplier',
  `tanggal`          DATETIME     DEFAULT CURRENT_TIMESTAMP,
  `pengguna_id`      INT          DEFAULT NULL COMMENT 'Staf yang melakukan eksekusi mutasi',
  CONSTRAINT `fk_mutasi_produk`
    FOREIGN KEY (`produk_id`) REFERENCES `produk` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mutasi_pengguna`
    FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Log Kartu Mutasi Stok Fisik Aeris Beaute';

-- ============================================================
-- TABEL 7: AKUN_REKENING (Bagan Akun / Chart of Accounts ERP)
-- ============================================================

CREATE TABLE `akun_rekening` (
  `kode_akun`      VARCHAR(20) PRIMARY KEY COMMENT 'Kode unik akun (misal: 101, 401, 501)',
  `nama_akun`      VARCHAR(100) NOT NULL   COMMENT 'Nama akun akuntansi',
  `kelompok_akun`  ENUM('Aset','Kewajiban','Ekuitas','Pendapatan','Beban_Pokok','Beban_Operasional')
                   NOT NULL COMMENT 'Klasifikasi laporan keuangan',
  `posisi_normal`  ENUM('Debit','Kredit') NOT NULL COMMENT 'Saldo normal akun',
  `saldo_awal`     DECIMAL(14,2) NOT NULL DEFAULT 0.00 COMMENT 'Saldo awal periode',
  `dibuat_pada`    DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Bagan Akun Keuangan Aeris Beaute (Chart of Accounts)';

-- ============================================================
-- TABEL 8: JURNAL_KEUANGAN (Buku Jurnal Umum Double-Entry)
-- ============================================================

CREATE TABLE `jurnal_keuangan` (
  `id`                    INT AUTO_INCREMENT PRIMARY KEY,
  `no_jurnal`             VARCHAR(40)  NOT NULL  COMMENT 'Nomor referensi voucher jurnal',
  `tanggal`               DATE         NOT NULL  COMMENT 'Tanggal transaksi akuntansi',
  `kode_akun`             VARCHAR(20)  NOT NULL  COMMENT 'Relasi ke tabel akun_rekening',
  `debit`                 DECIMAL(14,2) NOT NULL DEFAULT 0.00 COMMENT 'Nilai mutasi di sisi Debit',
  `kredit`                DECIMAL(14,2) NOT NULL DEFAULT 0.00 COMMENT 'Nilai mutasi di sisi Kredit',
  `keterangan`            VARCHAR(255) NOT NULL  COMMENT 'Uraian keterangan transaksi',
  `referensi_transaksi`   VARCHAR(50)  DEFAULT NULL COMMENT 'No Pesanan atau No Faktur Beban',
  `pengguna_id`           INT          DEFAULT NULL COMMENT 'Staf yang membukukan transaksi',
  `dibuat_pada`           DATETIME     DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_jurnal_akun`
    FOREIGN KEY (`kode_akun`) REFERENCES `akun_rekening` (`kode_akun`)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_jurnal_pengguna`
    FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Tabel Jurnal Umum Keuangan Double-Entry Aeris Beaute';

-- Kembalikan pengecekan foreign key
SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- DATA SAMPLE / DUMMY UNTUK PEMBELAJARAN & PENGUJIAN
-- Password default semua akun demo: 'password123'
-- Hash: $2y$10$h6wYCDRN.TkSvdHDKb.lJ.mAJVXewX4wisVkDbWbgI0Lr.3Gj8/Gq
-- ============================================================

-- 1. Data Akun Pengguna
INSERT INTO `pengguna`
  (`id`, `nama_lengkap`, `email`, `kata_sandi`, `no_telp`, `alamat`, `peran`, `status_aktif`)
VALUES
  (1, 'Administrator Utama ERP', 'admin@aerisbeaute.id',
   '$2y$10$h6wYCDRN.TkSvdHDKb.lJ.mAJVXewX4wisVkDbWbgI0Lr.3Gj8/Gq',
   '081234567890', 'Kantor Pusat Aeris Beaute, Jakarta Timur', 'superadmin', 1),
  (2, 'Staf Gudang & Logistik', 'gudang@aerisbeaute.id',
   '$2y$10$h6wYCDRN.TkSvdHDKb.lJ.mAJVXewX4wisVkDbWbgI0Lr.3Gj8/Gq',
   '081298765432', 'Gudang Aeris Beaute, Jakarta Timur', 'gudang', 1),
  (3, 'Kasir & Keuangan', 'kasir@aerisbeaute.id',
   '$2y$10$h6wYCDRN.TkSvdHDKb.lJ.mAJVXewX4wisVkDbWbgI0Lr.3Gj8/Gq',
   '081311223344', 'Kantor Kasir Aeris Beaute, Jakarta Timur', 'kasir', 1),
  (4, 'Nadira Putri (Pelanggan)', 'nadira@gmail.com',
   '$2y$10$h6wYCDRN.TkSvdHDKb.lJ.mAJVXewX4wisVkDbWbgI0Lr.3Gj8/Gq',
   '085677889900', 'Jl. Kemang Raya No. 12, Jakarta Selatan', 'pelanggan', 1),
  (5, 'Aulia Sari (Pelanggan)', 'aulia@gmail.com',
   '$2y$10$h6wYCDRN.TkSvdHDKb.lJ.mAJVXewX4wisVkDbWbgI0Lr.3Gj8/Gq',
   '087812345678', 'Jl. Malioboro No. 8, Yogyakarta', 'pelanggan', 1);

-- 2. Data Master Kategori Produk Aeris Beaute
INSERT INTO `kategori` (`id`, `nama_kategori`, `slug`, `deskripsi`) VALUES
  (1, 'Bar Soap', 'bar-soap',
   'Sabun batang premium Aeris Beaute dengan berbagai pilihan aroma Fresh, Sweet, dan Floral. Formulasi lembut untuk kulit sehat bercahaya.'),
  (2, 'Brush Set', 'brush-set',
   'Set kuas makeup profesional Aeris Beaute dengan bulu sintetis lembut berkualitas tinggi. Cocok untuk pemula maupun makeup artist.'),
  (3, 'Makeup Bag', 'makeup-bag',
   'Tas kosmetik dan pouch elegan Aeris Beaute berbahan premium untuk menyimpan dan membawa produk kecantikan dengan stylish.');

-- ============================================================
-- 3. Data Master Produk (Sumber: database_aeris_beaute.xlsx)
--    Kolom HPP (harga_beli) diestimasi berdasarkan margin standar
--    industri kosmetik lokal (estimasi 45-55% dari harga jual).
--    Kolom berat_gram diestimasi berdasarkan ukuran_isi produk.
--
--    CATATAN EDITOR: Harga Bar Soap AB001-AB006 di file Excel
--    increment 1 rupiah per baris (55000, 55001, 55002 dst).
--    Data dipertahankan sesuai sumber. Koreksi jika diperlukan.
-- ============================================================

INSERT INTO `produk`
  (`id`, `kategori_id`, `kode_produk`, `nama_produk`, `nama_varian`, `slug`, `deskripsi`,
   `kategori_aroma`, `ukuran_isi`, `asal_produk`, `dikirim_dari`, `jumlah_per_kemasan`,
   `harga_beli`, `harga_jual`, `stok`, `stok_minimum`, `berat_gram`, `gambar`, `status`)
VALUES
  -- === BAR SOAP (AB001-AB006) ===
  (1, 1, 'AB001', 'Aeris Beaute Blendie Bar Soap', 'Fine Linen',
   'aeris-blendie-bar-soap-fine-linen',
   'Sabun batang Aeris Beaute varian Fine Linen dengan aroma kain bersih yang segar dan mewah. Formulasi pelembab alami menjaga kelembaban kulit sepanjang hari.',
   'Fresh', '35 gr', 'Indonesia', 'Jakarta Timur', 1,
   30000.00, 55000.00, 50, 10, 100, 'aeris_soap_fine_linen.jpg', 'aktif'),

  (2, 1, 'AB002', 'Aeris Beaute Blendie Bar Soap', 'Sparkling Soda',
   'aeris-blendie-bar-soap-sparkling-soda',
   'Sabun batang varian Sparkling Soda dengan sensasi segar berkilau layaknya minuman soda dingin. Cocok untuk kulit yang butuh kesegaran ekstra.',
   'Fresh', '35 gr', 'Indonesia', 'Jakarta Timur', 1,
   30000.00, 55001.00, 50, 10, 100, 'aeris_soap_sparkling_soda.jpg', 'aktif'),

  (3, 1, 'AB003', 'Aeris Beaute Blendie Bar Soap', 'Candy Pop',
   'aeris-blendie-bar-soap-candy-pop',
   'Sabun batang manis varian Candy Pop dengan aroma permen yang menggemaskan. Favorit di kalangan pecinta skincare dengan aroma sweet dan playful.',
   'Sweet', '35 gr', 'Indonesia', 'Jakarta Timur', 1,
   30000.00, 55002.00, 50, 10, 100, 'aeris_soap_candy_pop.jpg', 'aktif'),

  (4, 1, 'AB004', 'Aeris Beaute Blendie Bar Soap', 'Jasmine Rouge',
   'aeris-blendie-bar-soap-jasmine-rouge',
   'Sabun batang elegan varian Jasmine Rouge dengan perpaduan aroma melati dan sentuhan merah mawar yang romantis. Memberikan nuansa mandi yang mewah.',
   'Floral', '35 gr', 'Indonesia', 'Jakarta Timur', 1,
   30000.00, 55003.00, 50, 10, 100, 'aeris_soap_jasmine_rouge.jpg', 'aktif'),

  (5, 1, 'AB005', 'Aeris Beaute Blendie Bar Soap', 'Lavender',
   'aeris-blendie-bar-soap-lavender',
   'Sabun batang relaksasi varian Lavender dengan aroma bunga lavender asli yang menenangkan. Sempurna untuk rutinitas mandi sebelum tidur.',
   'Floral', '35 gr', 'Indonesia', 'Jakarta Timur', 1,
   30000.00, 55004.00, 50, 10, 100, 'aeris_soap_lavender.jpg', 'aktif'),

  (6, 1, 'AB006', 'Aeris Beaute Blendie Bar Soap', 'Blooming Rose',
   'aeris-blendie-bar-soap-blooming-rose',
   'Sabun batang feminin varian Blooming Rose dengan aroma bunga mawar segar yang mekar. Mengandung ekstrak rosehip untuk kulit cerah dan lembut.',
   'Floral', '35 gr', 'Indonesia', 'Jakarta Timur', 1,
   30000.00, 55005.00, 50, 10, 100, 'aeris_soap_blooming_rose.jpg', 'aktif'),

  -- === BRUSH SET (AB007-AB008) ===
  (7, 2, 'AB007', 'Aeris Beaute Brush Set', 'The Onyx 2.0 Brush Set',
   'aeris-brush-set-onyx-2-0',
   'Set kuas makeup premium 15 pcs Aeris Beaute edisi The Onyx 2.0 dengan handle hitam elegan dan bulu sintetis ultra-lembut. Dilengkapi pouch penyimpanan eksklusif.',
   '-', '15 pcs', 'Indonesia', 'Jakarta Timur', 1,
   170000.00, 313000.00, 100, 15, 450, 'aeris_brush_onyx.jpg', 'aktif'),

  (8, 2, 'AB008', 'Aeris Beaute Brush Set', 'The Signature Baby Brush Set',
   'aeris-brush-set-signature-baby',
   'Set kuas mini 5 pcs Aeris Beaute edisi The Signature Baby cocok untuk daily makeup dan travel. Ringan, kompak, dan sempurna untuk pemula yang baru mulai belajar makeup.',
   '-', '5 pcs', 'Indonesia', 'Jakarta Timur', 1,
   185000.00, 330000.00, 100, 15, 280, 'aeris_brush_signature.jpg', 'aktif'),

  -- === MAKEUP BAG (AB009-AB010) ===
  (9, 3, 'AB009', 'Aeris Beaute Makeup Bag', 'The Coco Vanity Bag',
   'aeris-makeup-bag-coco-vanity',
   'Tas kosmetik premium Aeris Beaute edisi The Coco Vanity Bag dengan desain mewah bertekstur kulit sintetis berpola. Kapasitas lega dengan cermin built-in di bagian dalam.',
   '-', '1 pcs', 'Indonesia', 'Jakarta Timur', 1,
   250000.00, 460000.00, 40, 8, 650, 'aeris_bag_coco_vanity.jpg', 'aktif'),

  (10, 3, 'AB010', 'Aeris Beaute Makeup Bag', 'The Loulou Leather Pouch',
   'aeris-makeup-bag-loulou-leather',
   'Pouch kosmetik Aeris Beaute edisi The Loulou Leather dengan bahan kulit sintetis premium warna nude. Desain minimalis dan elegan, cocok sebagai kado maupun koleksi pribadi.',
   '-', '1 pcs', 'Indonesia', 'Jakarta Timur', 1,
   185000.00, 330000.00, 40, 8, 520, 'aeris_bag_loulou_leather.jpg', 'aktif');

-- ============================================================
-- 4. Data Master Bagan Akun (Chart of Accounts - Aeris Beaute)
--    Nilai saldo awal persediaan dihitung dari data stok Excel:
--    - Bar Soap (AB001-AB006) : 6 varian x 50 unit x Rp30.000 = Rp9.000.000
--    - Brush Set (AB007)      : 100 unit x Rp170.000            = Rp17.000.000
--    - Brush Set (AB008)      : 100 unit x Rp185.000            = Rp18.500.000
--    - Makeup Bag (AB009)     : 40 unit x Rp250.000             = Rp10.000.000
--    - Makeup Bag (AB010)     : 40 unit x Rp185.000             = Rp7.400.000
--    Total Nilai Persediaan   :                                  = Rp61.900.000
-- ============================================================

INSERT INTO `akun_rekening`
  (`kode_akun`, `nama_akun`, `kelompok_akun`, `posisi_normal`, `saldo_awal`)
VALUES
  ('101', 'Kas di Tangan / Kas Toko',              'Aset',              'Debit',  8000000.00),
  ('102', 'Kas di Bank (Rekening Utama)',           'Aset',              'Debit',  20000000.00),
  ('103', 'Piutang Usaha (COD / Marketplace)',      'Aset',              'Debit',  0.00),
  ('104', 'Persediaan Barang Dagangan (Kosmetik)',  'Aset',              'Debit',  61900000.00),
  ('201', 'Utang Usaha (Pemasok Produk)',           'Kewajiban',         'Kredit', 0.00),
  ('301', 'Modal Pemilik Aeris Beaute',             'Ekuitas',           'Kredit', 89900000.00),
  ('401', 'Pendapatan Penjualan Produk',            'Pendapatan',        'Kredit', 0.00),
  ('501', 'Beban Pokok Penjualan (HPP)',            'Beban_Pokok',       'Debit',  0.00),
  ('601', 'Beban Operasional & Pengiriman',         'Beban_Operasional', 'Debit',  0.00),
  ('602', 'Beban Listrik, Internet & Utilitas',     'Beban_Operasional', 'Debit',  0.00),
  ('603', 'Beban Promosi & Iklan Digital',          'Beban_Operasional', 'Debit',  0.00),
  ('604', 'Beban Kemasan & Packing Material',       'Beban_Operasional', 'Debit',  0.00);

-- ============================================================
-- 5. Data Transaksi Sampel Pesanan
-- ============================================================

INSERT INTO `pesanan`
  (`id`, `no_pesanan`, `pengguna_id`, `tanggal_pesanan`, `total_belanja`, `ongkir`,
   `total_bayar`, `status_pesanan`, `status_pembayaran`, `metode_pembayaran`, `kurir`,
   `nomor_resi`, `nama_penerima`, `no_telp_penerima`, `alamat_pengiriman`, `catatan`)
VALUES
  (1, 'ORD-20260901-001', 4, '2026-09-01 10:30:00',
   368000.00, 15000.00, 383000.00,
   'selesai', 'lunas', 'transfer_bank', 'JNE Regular', 'JNE7722334455',
   'Nadira Putri', '085677889900',
   'Jl. Kemang Raya No. 12, Jakarta Selatan', 'Bubble wrap ya kak, produknya hadiah'),
  (2, 'ORD-20260905-002', 5, '2026-09-05 14:15:00',
   313000.00, 20000.00, 333000.00,
   'diproses', 'lunas', 'transfer_bank', 'SiCepat BEST', NULL,
   'Aulia Sari', '087812345678',
   'Jl. Malioboro No. 8, Yogyakarta', 'Sertakan nota sebagai kado'),
  (3, 'ORD-20260912-003', 4, '2026-09-12 09:00:00',
   460000.00, 18000.00, 478000.00,
   'menunggu_pembayaran', 'belum_lunas', 'transfer_bank', 'J&T Express', NULL,
   'Nadira Putri', '085677889900',
   'Jl. Kemang Raya No. 12, Jakarta Selatan', 'Segera konfirmasi setelah transfer');

-- ============================================================
-- 6. Data Detail Pesanan Sampel
--    Pesanan 1 (ORD-20260901-001): Bar Soap Fine Linen x1 + Makeup Bag Loulou x1
--    Pesanan 2 (ORD-20260905-002): Brush Set Onyx 2.0 x1
--    Pesanan 3 (ORD-20260912-003): Makeup Bag Coco Vanity x1
-- ============================================================

INSERT INTO `detail_pesanan`
  (`id`, `pesanan_id`, `produk_id`, `nama_varian`, `kuantitas`,
   `harga_satuan`, `hpp_satuan`, `subtotal`)
VALUES
  (1, 1, 1,  'Fine Linen',              1,  55000.00,  30000.00,  55000.00),
  (2, 1, 10, 'The Loulou Leather Pouch',1, 330000.00, 185000.00, 330000.00),
  (3, 2, 7,  'The Onyx 2.0 Brush Set',  1, 313000.00, 170000.00, 313000.00),
  (4, 3, 9,  'The Coco Vanity Bag',     1, 460000.00, 250000.00, 460000.00);

-- ============================================================
-- 7. Data Mutasi Stok Sampel
-- ============================================================

INSERT INTO `mutasi_stok`
  (`id`, `produk_id`, `jenis_mutasi`, `jumlah`, `stok_sebelum`, `stok_sesudah`,
   `nomor_referensi`, `keterangan`, `tanggal`, `pengguna_id`)
VALUES
  -- Stok masuk awal (restock dari supplier)
  (1,  1,  'masuk_restock', 51, 0, 51,  'PO-SUPP-AB-001', 'Penerimaan stok awal Bar Soap Fine Linen dari supplier', '2026-08-20 08:00:00', 2),
  (2,  2,  'masuk_restock', 50, 0, 50,  'PO-SUPP-AB-001', 'Penerimaan stok awal Bar Soap Sparkling Soda',           '2026-08-20 08:00:00', 2),
  (3,  3,  'masuk_restock', 50, 0, 50,  'PO-SUPP-AB-001', 'Penerimaan stok awal Bar Soap Candy Pop',                '2026-08-20 08:00:00', 2),
  (4,  4,  'masuk_restock', 50, 0, 50,  'PO-SUPP-AB-001', 'Penerimaan stok awal Bar Soap Jasmine Rouge',            '2026-08-20 08:00:00', 2),
  (5,  5,  'masuk_restock', 50, 0, 50,  'PO-SUPP-AB-001', 'Penerimaan stok awal Bar Soap Lavender',                 '2026-08-20 08:00:00', 2),
  (6,  6,  'masuk_restock', 50, 0, 50,  'PO-SUPP-AB-001', 'Penerimaan stok awal Bar Soap Blooming Rose',            '2026-08-20 08:00:00', 2),
  (7,  7,  'masuk_restock', 100, 0, 100,'PO-SUPP-AB-002', 'Penerimaan stok awal Brush Set Onyx 2.0',                '2026-08-20 09:00:00', 2),
  (8,  8,  'masuk_restock', 100, 0, 100,'PO-SUPP-AB-002', 'Penerimaan stok awal Brush Set Signature Baby',          '2026-08-20 09:00:00', 2),
  (9,  9,  'masuk_restock', 40,  0, 40, 'PO-SUPP-AB-003', 'Penerimaan stok awal Makeup Bag Coco Vanity',            '2026-08-21 10:00:00', 2),
  (10, 10, 'masuk_restock', 40,  0, 40, 'PO-SUPP-AB-003', 'Penerimaan stok awal Makeup Bag Loulou Leather',         '2026-08-21 10:00:00', 2),

  -- Stok keluar penjualan
  (11, 1,  'keluar_penjualan', -1, 51, 50, 'ORD-20260901-001', 'Penjualan Bar Soap Fine Linen ke Nadira Putri',         '2026-09-01 10:35:00', 3),
  (12, 10, 'keluar_penjualan', -1, 40, 39, 'ORD-20260901-001', 'Penjualan Makeup Bag Loulou ke Nadira Putri',            '2026-09-01 10:35:00', 3),
  (13, 7,  'keluar_penjualan', -1, 100, 99,'ORD-20260905-002', 'Penjualan Brush Set Onyx 2.0 ke Aulia Sari',            '2026-09-05 14:20:00', 3);

-- ============================================================
-- 8. Data Jurnal Keuangan Sampel (Double-Entry)
-- ============================================================

INSERT INTO `jurnal_keuangan`
  (`no_jurnal`, `tanggal`, `kode_akun`, `debit`, `kredit`,
   `keterangan`, `referensi_transaksi`, `pengguna_id`)
VALUES
  -- Transaksi 1: Penjualan ORD-20260901-001 (Lunas, total bayar Rp383.000)
  ('JRN-20260901-001', '2026-09-01', '102', 368000.00, 0.00,
   'Penerimaan Kas Penjualan Produk ORD-20260901-001', 'ORD-20260901-001', 3),
  ('JRN-20260901-001', '2026-09-01', '401', 0.00, 368000.00,
   'Pendapatan Penjualan Produk ORD-20260901-001', 'ORD-20260901-001', 3),
  -- HPP Pesanan 1 (30.000 + 185.000 = 215.000)
  ('JRN-20260901-002', '2026-09-01', '501', 215000.00, 0.00,
   'Pengakuan HPP Beban Pokok Penjualan ORD-20260901-001', 'ORD-20260901-001', 3),
  ('JRN-20260901-002', '2026-09-01', '104', 0.00, 215000.00,
   'Pengurangan Nilai Persediaan Barang Dagangan ORD-20260901-001', 'ORD-20260901-001', 3),
  -- Ongkir Pesanan 1
  ('JRN-20260901-003', '2026-09-01', '102', 15000.00, 0.00,
   'Penerimaan Ongkos Kirim ORD-20260901-001', 'ORD-20260901-001', 3),
  ('JRN-20260901-003', '2026-09-01', '601', 0.00, 15000.00,
   'Beban Pengiriman JNE Regular ORD-20260901-001', 'ORD-20260901-001', 3),

  -- Transaksi 2: Penjualan ORD-20260905-002 (Lunas, total bayar Rp333.000)
  ('JRN-20260905-001', '2026-09-05', '102', 313000.00, 0.00,
   'Penerimaan Kas Penjualan Produk ORD-20260905-002', 'ORD-20260905-002', 3),
  ('JRN-20260905-001', '2026-09-05', '401', 0.00, 313000.00,
   'Pendapatan Penjualan Produk ORD-20260905-002', 'ORD-20260905-002', 3),
  -- HPP Pesanan 2 (170.000)
  ('JRN-20260905-002', '2026-09-05', '501', 170000.00, 0.00,
   'Pengakuan HPP Beban Pokok Penjualan ORD-20260905-002', 'ORD-20260905-002', 3),
  ('JRN-20260905-002', '2026-09-05', '104', 0.00, 170000.00,
   'Pengurangan Nilai Persediaan Barang Dagangan ORD-20260905-002', 'ORD-20260905-002', 3),
  -- Ongkir Pesanan 2
  ('JRN-20260905-003', '2026-09-05', '102', 20000.00, 0.00,
   'Penerimaan Ongkos Kirim ORD-20260905-002', 'ORD-20260905-002', 3),
  ('JRN-20260905-003', '2026-09-05', '601', 0.00, 20000.00,
   'Beban Pengiriman SiCepat BEST ORD-20260905-002', 'ORD-20260905-002', 3),

  -- Transaksi 3: Pembayaran Listrik & Internet September
  ('JRN-20260908-001', '2026-09-08', '602', 550000.00, 0.00,
   'Pembayaran Tagihan Listrik & Internet Kantor Bulan September', 'OPS-SEP-001', 1),
  ('JRN-20260908-001', '2026-09-08', '101', 0.00, 550000.00,
   'Kas Toko Keluar untuk Beban Listrik & Internet', 'OPS-SEP-001', 1),

  -- Transaksi 4: Pembayaran iklan digital / social media
  ('JRN-20260910-001', '2026-09-10', '603', 300000.00, 0.00,
   'Pembayaran Iklan Instagram & TikTok Ads September', 'ADS-SEP-001', 1),
  ('JRN-20260910-001', '2026-09-10', '101', 0.00, 300000.00,
   'Kas Toko Keluar untuk Beban Promosi Digital', 'ADS-SEP-001', 1);

-- ============================================================
-- END OF SCRIPT: db_aeris_beaute
-- Verifikasi: Cek total debit = total kredit setiap no_jurnal
-- SELECT no_jurnal, SUM(debit) AS total_debit, SUM(kredit) AS total_kredit
-- FROM jurnal_keuangan GROUP BY no_jurnal;
-- ============================================================
