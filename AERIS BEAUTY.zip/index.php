<?php require 'koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <style>
        /* Mengadopsi style uppercase, font bold bersih, dan warna kontras dari Fenty Beauty[cite: 2] */
        body { font-family: 'Arial', sans-serif; margin: 0; background: #fff; color: #000; }
        .navbar { display: flex; justify-content: space-between; align-items: center; padding: 15px 40px; border-bottom: 1px solid #eee; font-weight: bold; }
        .nav-links a { margin: 0 15px; text-decoration: none; color: #000; text-transform: uppercase; font-size: 14px;}
        .hero { position: relative; text-align: center; color: white; background: url('image/banner/layout1.png') center/cover; padding: 150px 20px; }
        .hero h1 { font-size: 50px; text-transform: uppercase; letter-spacing: 2px; }
        .product-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; padding: 40px; }
        .card { border: 1px solid #f0f0f0; text-align: center; padding: 20px; }
        .card img { width: 100%; height: auto; }
        .price { font-weight: bold; margin: 10px 0; }
        .btn-shop { background: #000; color: #fff; padding: 10px 20px; text-decoration: none; text-transform: uppercase; font-weight: bold; }
        footer { background: #111; color: #fff; padding: 40px; text-align: center; }
    </style>
</head>
<body>
    <!-- Navbar -->
    <div class="navbar">
        <div class="logo"><img src="AERIS BEAUTY.jpeg" width="120" alt="AERIS"></div>
        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="kategori.php">Kategori</a>
            <a href="about.php">Tentang Kami</a>
            <a href="faq.php">FAQ</a>
            <a href="kontak.php">Kontak</a>
        </div>
        <div class="nav-icons">
            🔍 🛒 🔔 👤
        </div>
    </div>

    <!-- Hero Section -->
    <div class="hero">
        <h1>AERIS BEAUTE</h1>
        <p>Premium Beauty Tools & Cosmetics</p>
        <a href="#shop" class="btn-shop">SHOP NOW</a>
    </div>

    <h2 style="text-align: center; margin-top: 40px;">FOREVER FAVES</h2>
    
    <!-- Product Grid (Limit 10) -->
    <div class="product-grid" id="shop">
        <?php
        // Mengambil produk dari database[cite: 4]
        $q = mysqli_query($conn, "SELECT * FROM produk WHERE status='aktif' LIMIT 10");
        while($row = mysqli_fetch_assoc($q)):
        ?>
        <div class="card">
            <img src="fine_linen_aeris.jpeg<?= $row['gambar'] ?>" alt="<?= $row['nama_produk'] ?>">
            <h3><?= $row['nama_produk'] ?></h3>
            <p><?= $row['nama_varian'] ?></p>
            <p class="price">Rp <?= number_format($row['harga_jual'], 0, ',', '.') ?></p>
            <a href="detail.php?id=<?= $row['id'] ?>" class="btn-shop">ADD TO BAG</a>
        </div>
        <?php endwhile; ?>
    </div>

    <footer>
        <h2>DOWN FOR MORE? WE GOT YOU!</h2>
        <p>Crafted to elevate your daily beauty routine.</p>
        <p>SHOP | ABOUT US | HELP | CONTACT</p>
    </footer>
</body>
</html>