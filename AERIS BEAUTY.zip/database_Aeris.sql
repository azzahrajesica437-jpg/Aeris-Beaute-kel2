-- ============================================================
-- SKRIP BASIS DATA LENGKAP: E-COMMERCE SEPATU TERINTEGRASI MODEL ERP
-- Program Studi: Sistem Informasi / Teknik Informatika
-- Modul: Aplikasi Web PHP Native MVC Murni
-- Database: db_sepatu_erp
-- ============================================================

-- 1. Buat Basis Data jika belum ada
CREATE DATABASE IF NOT EXISTS `db_sepatu_erp` DEFAULT CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;
USE `db_sepatu_erp`;

-- Nonaktifkan pengecekan foreign key sementara untuk inisialisasi ulang yang bersih
SET FOREIGN_KEY_CHECKS = 0;

-- Hapus tabel lama jika ada (urutan drop yang aman)
DROP TABLE IF EXISTS `jurnal_keuangan`;
DROP TABLE IF EXISTS `akun_rekening`;
DROP TABLE IF EXISTS `mutasi_stok`;
DROP TABLE IF EXISTS `detail_pesanan`;
DROP TABLE IF EXISTS `pesanan`;
DROP TABLE IF EXISTS `produk`;
DROP TABLE IF EXISTS `kategori`;
DROP TABLE IF EXISTS `pengguna`;

-- ============================================================
-- TABEL 1: PENGGUNA (Tabel Master Akun & Hak Akses)
-- Peran:
-- - 'superadmin': Mengakses seluruh menu ERP, user, keuangan, dan toko
-- - 'gudang': Mengelola stok masuk, opname, dan katalog produk
-- - 'kasir': Memproses pesanan dan verifikasi pembayaran
-- - 'pelanggan': Melakukan transaksi belanja online di front-end
-- ============================================================

CREATE TABLE `pengguna` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nama_lengkap` VARCHAR(100) NOT NULL COMMENT 'Nama lengkap pemilik akun',
  `email` VARCHAR(100) NOT NULL UNIQUE COMMENT 'Email aktif untuk login',
  `kata_sandi` VARCHAR(255) NOT NULL COMMENT 'Password yang dienkripsi dengan password_hash()',
  `no_telp` VARCHAR(20) DEFAULT NULL COMMENT 'Nomor kontak WhatsApp / HP',
  `alamat` TEXT DEFAULT NULL COMMENT 'Alamat lengkap pengiriman atau tempat tinggal',
  `peran` ENUM('superadmin', 'gudang', 'kasir', 'pelanggan') NOT NULL DEFAULT 'pelanggan'
  COMMENT 'Hak akses dalam sistem',
  `status_aktif` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1 = Aktif, 0 = Diblokir/Nonaktif',
  `dibuat_pada` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT 'Waktu pendaftaran akun',
  `diperbarui_pada` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Tabel data pengguna dan hak akses ERP';

-- ============================================================
-- TABEL 2: KATEGORI (Tabel Master Kategori Sepatu)
-- ============================================================

CREATE TABLE `kategori` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nama_kategori` VARCHAR(100) NOT NULL COMMENT 'Nama kategori sepatu (misal: Sneakers, Formal, Running)',
  `slug` VARCHAR(120) NOT NULL UNIQUE COMMENT 'Slug ramah URL',
  `deskripsi` TEXT DEFAULT NULL COMMENT 'Penjelasan singkat kategori',
  `dibuat_pada` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Master Kategori Sepatu';

-- ============================================================
-- TABEL 3: PRODUK (Master Data Sepatu & Persediaan)
-- Mencatat HPP (Harga Pokok Pembelian) untuk kalkulasi akuntansi laba kotor.
-- ============================================================

CREATE TABLE `produk` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `kategori_id` INT NOT NULL COMMENT 'Relasi ke tabel kategori',
  `kode_produk` VARCHAR(30) NOT NULL UNIQUE COMMENT 'SKU / Barcode unik produk (misal: SPT-SNK-001)',
  `nama_produk` VARCHAR(150) NOT NULL COMMENT 'Nama komersial sepatu',
  `slug` VARCHAR(180) NOT NULL UNIQUE COMMENT 'Slug untuk URL detail produk',
  `deskripsi` TEXT DEFAULT NULL COMMENT 'Deskripsi detail spesifikasi dan bahan sepatu',
  `ukuran` VARCHAR(50) NOT NULL DEFAULT '39, 40, 41, 42, 43' COMMENT 'Pilihan ukuran sepatu yang tersedia',
  `harga_beli` DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT 'HPP (Harga Pokok Pembelian) satuan saat restock',
  `harga_jual` DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT 'Harga jual ke konsumen e-commerce',
  `stok` INT NOT NULL DEFAULT 0 COMMENT 'Jumlah stok fisik saat ini',
  `stok_minimum` INT NOT NULL DEFAULT 5 COMMENT 'Batas peringatan stok menipis pada dashboard ERP',
  `berat_gram` INT NOT NULL DEFAULT 1000 COMMENT 'Berat produk dalam gram untuk hitung ongkir',
  `gambar` VARCHAR(255) DEFAULT 'default_sepatu.jpg' COMMENT 'Nama file foto produk',
  `status` ENUM('aktif', 'nonaktif') NOT NULL DEFAULT 'aktif' COMMENT 'Status tayang di katalog',
  `dibuat_pada` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `diperbarui_pada` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_produk_kategori` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`) ON DELETE
  RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Master Data Produk dan Persediaan Sepatu';

-- ============================================================
-- TABEL 4: PESANAN (Header Transaksi Penjualan E-Commerce)
-- ============================================================

CREATE TABLE `pesanan` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `no_pesanan` VARCHAR(40) NOT NULL UNIQUE COMMENT 'Nomor unik transaksi (contoh: ORD-20260912-001)',
  `pengguna_id` INT NOT NULL COMMENT 'ID pelanggan yang berbelanja',
  `tanggal_pesanan` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT 'Waktu checkout dilakukan',
  `total_belanja` DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT 'Subtotal harga produk',
  `ongkir` DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT 'Biaya pengiriman kurir',
  `total_bayar` DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT 'Total belanja + ongkir',
  `status_pesanan` ENUM('menunggu_pembayaran', 'diproses', 'dikirim', 'selesai', 'dibatalkan') NOT NULL
  DEFAULT 'menunggu_pembayaran' COMMENT 'Status alur pesanan',
  `status_pembayaran` ENUM('belum_lunas', 'lunas') NOT NULL DEFAULT 'belum_lunas' COMMENT
  'Status finansial pesanan',
  `metode_pembayaran` ENUM('transfer_bank', 'cod') NOT NULL DEFAULT 'transfer_bank' COMMENT
  'Metode pembayaran yang dipilih',
  `kurir` VARCHAR(50) NOT NULL DEFAULT 'JNE Regular' COMMENT
  'Ekspedisi pengiriman (JNE, J&T, SiCepat, dll)',
  `nomor_resi` VARCHAR(50) DEFAULT NULL COMMENT 'Nomor resi paket dari ekspedisi',
  `nama_penerima` VARCHAR(100) NOT NULL COMMENT 'Nama tujuan kirim',
  `no_telp_penerima` VARCHAR(20) NOT NULL COMMENT 'Nomor telepon tujuan',
  `alamat_pengiriman` TEXT NOT NULL COMMENT 'Alamat tujuan lengkap',
  `catatan` TEXT DEFAULT NULL COMMENT 'Catatan tambahan dari pembeli',
  `bukti_transfer` VARCHAR(255) DEFAULT NULL COMMENT 'File upload bukti transfer bank',
  `dibuat_pada` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `diperbarui_pada` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_pesanan_pengguna` FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`)
  ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Header Transaksi Pesanan Penjualan';

-- ============================================================
-- TABEL 5: DETAIL_PESANAN (Rincian Item yang Dipesan)
-- Menyimpan HPP satuan pada saat pesanan dibuat agar laporan laba rugi akurat.
-- ============================================================

CREATE TABLE `detail_pesanan` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `pesanan_id` INT NOT NULL COMMENT 'Relasi ke tabel pesanan',
  `produk_id` INT NOT NULL COMMENT 'Relasi ke tabel produk',
  `ukuran_dipilih` VARCHAR(10) NOT NULL DEFAULT '41' COMMENT 'Ukuran sepatu yang dipilih pembeli',
  `kuantitas` INT NOT NULL DEFAULT 1 COMMENT 'Jumlah pasang yang dibeli',
  `harga_satuan` DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT 'Harga jual satuan saat transaksi',
  `hpp_satuan` DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT
  'Harga Pokok Pembelian satuan saat transaksi (untuk Laba/Rugi)',
  `subtotal` DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT 'kuantitas * harga_satuan',
  CONSTRAINT `fk_detail_pesanan` FOREIGN KEY (`pesanan_id`) REFERENCES `pesanan` (`id`)
  ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_detail_produk` FOREIGN KEY (`produk_id`) REFERENCES `produk` (`id`)
  ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Detail Item Produk per Pesanan';

-- ============================================================
-- TABEL 6: MUTASI_STOK (Kartu Stok & Audit Trail Inventaris)
-- Setiap barang masuk, barang keluar, atau penyesuaian opname dicatat di sini.
-- ============================================================

CREATE TABLE `mutasi_stok` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `produk_id` INT NOT NULL COMMENT 'ID produk yang termutasi',
  `jenis_mutasi` ENUM('masuk_restock', 'keluar_penjualan', 'penyesuaian_opname', 'retur_masuk')
  NOT NULL COMMENT 'Jenis perubahan stok',
  `jumlah` INT NOT NULL COMMENT 'Banyaknya barang yang bertambah (+) atau berkurang (-)',
  `stok_sebelum` INT NOT NULL COMMENT 'Jumlah stok sebelum aksi dilakukan',
  `stok_sesudah` INT NOT NULL COMMENT 'Jumlah stok setelah aksi dilakukan',
  `nomor_referensi` VARCHAR(50) DEFAULT NULL COMMENT 'Nomor Pesanan atau No Faktur Supplier',
  `keterangan` TEXT DEFAULT NULL COMMENT 'Catatan alasan mutasi atau nama supplier',
  `tanggal` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `pengguna_id` INT DEFAULT NULL COMMENT 'Staf yang melakukan eksekusi mutasi',
  CONSTRAINT `fk_mutasi_produk` FOREIGN KEY (`produk_id`) REFERENCES `produk` (`id`)
  ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mutasi_pengguna` FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`)
  ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Log Kartu Mutasi Stok Fisik';

-- ============================================================
-- TABEL 7: AKUN_REKENING (Chart of Accounts / Bagan Akun Standar ERP)
-- Standar Akuntansi Keuangan Sederhana untuk Perusahaan Dagang.
-- ============================================================

CREATE TABLE `akun_rekening` (
  `kode_akun` VARCHAR(20) PRIMARY KEY COMMENT 'Kode unik akun (misal: 101, 401, 501)',
  `nama_akun` VARCHAR(100) NOT NULL COMMENT 'Nama akun akuntansi',
  `kelompok_akun` ENUM('Aset', 'Kewajiban', 'Ekuitas', 'Pendapatan', 'Beban_Pokok', 'Beban_Operasional')
  NOT NULL COMMENT 'Klasifikasi laporan keuangan',
  `posisi_normal` ENUM('Debit', 'Kredit') NOT NULL COMMENT 'Saldo normal akun',
  `saldo_awal` DECIMAL(14,2) NOT NULL DEFAULT 0.00 COMMENT 'Saldo awal periode',
  `dibuat_pada` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Bagan Akun Keuangan (Chart of Accounts)';

-- ============================================================
-- TABEL 8: JURNAL_KEUANGAN (Buku Jurnal Umum Double-Entry)
-- Menampung baris Debit dan Kredit yang harus seimbang (Balance).
-- ============================================================

CREATE TABLE `jurnal_keuangan` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `no_jurnal` VARCHAR(40) NOT NULL COMMENT 'Nomor referensi voucher jurnal (misal: JRN-202609-001)',
  `tanggal` DATE NOT NULL COMMENT 'Tanggal transaksi akuntansi',
  `kode_akun` VARCHAR(20) NOT NULL COMMENT 'Relasi ke tabel akun_rekening',
  `debit` DECIMAL(14,2) NOT NULL DEFAULT 0.00 COMMENT 'Nilai mutasi di sisi Debit',
  `kredit` DECIMAL(14,2) NOT NULL DEFAULT 0.00 COMMENT 'Nilai mutasi di sisi Kredit',
  `keterangan` VARCHAR(255) NOT NULL COMMENT 'Uraian keterangan transaksi',
  `referensi_transaksi` VARCHAR(50) DEFAULT NULL COMMENT 'No Pesanan atau No Faktur Beban',
  `pengguna_id` INT DEFAULT NULL COMMENT 'Staf yang membukukan transaksi',
  `dibuat_pada` DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_jurnal_akun` FOREIGN KEY (`kode_akun`) REFERENCES `akun_rekening` (`kode_akun`)
  ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_jurnal_pengguna` FOREIGN KEY (`pengguna_id`) REFERENCES `pengguna` (`id`)
  ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Tabel Jurnal Umum Keuangan Double-Entry';

-- Kembalikan pengecekan foreign key
SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- DATA DUMMY / SAMPLE DATA UNTUK PEMBELAJARAN & PENGUJIAN MAHASISWA
-- ============================================================

-- 1. Data Akun Pengguna (Password default: 'password123' untuk semua akun demo)
-- Hash password valid dibuat menggunakan password_hash('password123', PASSWORD_BCRYPT)
-- Hash: $2y$10$h6wYCDRN.TkSvdHDKb.lJ.mAJVXewX4wisVkDbWbgI0Lr.3Gj8/Gq
INSERT INTO `pengguna` (`id`, `nama_lengkap`, `email`, `kata_sandi`, `no_telp`, `alamat`, `peran`,
`status_aktif`) VALUES
(1, 'Administrator Utama ERP', 'admin@sepatuerp.com',
'$2y$10$h6wYCDRN.TkSvdHDKb.lJ.mAJVXewX4wisVkDbWbgI0Lr.3Gj8/Gq',
'081234567890', 'Gedung Pusat Operasional ERP, Jakarta', 'superadmin', 1),
(2, 'Staf Gudang & Logistik', 'gudang@sepatuerp.com',
'$2y$10$h6wYCDRN.TkSvdHDKb.lJ.mAJVXewX4wisVkDbWbgI0Lr.3Gj8/Gq',
'081298765432', 'Gudang Utama Distribusi, Bekasi', 'gudang', 1),
(3, 'Kasir & Keuangan', 'kasir@sepatuerp.com',
'$2y$10$h6wYCDRN.TkSvdHDKb.lJ.mAJVXewX4wisVkDbWbgI0Lr.3Gj8/Gq',
'081311223344', 'Kantor Kasir & Finance, Jakarta', 'kasir', 1),
(4, 'Budi Santoso (Pelanggan)', 'budi@gmail.com',
'$2y$10$h6wYCDRN.TkSvdHDKb.lJ.mAJVXewX4wisVkDbWbgI0Lr.3Gj8/Gq',
'085677889900', 'Jl. Merdeka No. 45, Bandung, Jawa Barat', 'pelanggan', 1),
(5, 'Siti Rahma (Pelanggan)', 'siti@gmail.com',
'$2y$10$h6wYCDRN.TkSvdHDKb.lJ.mAJVXewX4wisVkDbWbgI0Lr.3Gj8/Gq',
'087812345678', 'Jl. Malioboro No. 12, Yogyakarta', 'pelanggan', 1);

-- 2. Data Master Kategori Sepatu
INSERT INTO `kategori` (`id`, `nama_kategori`, `slug`, `deskripsi`) VALUES
(1, 'Sneakers Casual', 'sneakers-casual', 'Sepatu kasual santai untuk aktivitas harian, kuliah,
dan hangout dengan desain trendi.'),
(2, 'Sepatu Olahraga (Running)', 'sepatu-olahraga-running', 'Sepatu lari dan olahraga dengan
bantalan empuk, ringan, dan sirkulasi udara optimal.'),
(3, 'Sepatu Formal Pantofel', 'sepatu-formal-pantofel', 'Sepatu kulit pria dan wanita untuk
acara formal, perkantoran, dan pesta.'),
(4, 'Boots & Outdoor', 'boots-outdoor', 'Sepatu boots tangguh berbahan kulit sintetis premium
\untuk petualangan dan gaya maskulin.'),
(5, 'Slip On & Loafers', 'slip-on-loafers', 'Sepatu praktis tanpa tali, nyaman digunakan cepat
dan tetap berpenampilan rapi.');

-- 3. Data Master Produk Sepatu
INSERT INTO `produk` (`id`, `kategori_id`, `kode_produk`, `nama_produk`, `slug`, `deskripsi`,
`ukuran`, `harga_beli`, `harga_jual`, `stok`, `stok_minimum`, `berat_gram`, `gambar`, `status`) VALUES
(1, 1, 'SPT-SNK-001', 'Aerostep Classic White Sneakers', 'aerostep-classic-white-sneakers',
'Sneakers putih klasik dengan sol karet antiselip, bahan kanvas breathable kualitas tinggi
yang sangat nyaman dipakai seharian penuh.', '39, 40, 41, 42, 43', 180000.00, 299000.00, 25, 5, 800,
'sepatu_sneaker_white.svg', 'aktif'),
(2, 1, 'SPT-SNK-002', 'Urban Streetwear High-Top Black', 'urban-streetwear-high-top-black',
'Sepatu sneakers model high-top warna hitam pekat dengan sentuhan gaya urban kekinian. Material kulit
sintetis premium tahan percikan air.', '40, 41, 42, 43, 44', 210000.00, 349000.00, 18, 5, 950,
'sepatu_sneaker_black.svg', 'aktif'),
(3, 2, 'SPT-RUN-001', 'HyperPulse Running Shoes Neon Red', 'hyperpulse-running-shoes-neon-red',
'Sepatu lari performa tinggi dengan teknologi bantalan busa Phylon ultra-ringan dan upper mesh
fleksibel yang membuat langkah lebih bertenaga.', '39, 40, 41, 42, 43', 250000.00, 425000.00, 30, 6, 650,
'sepatu_running_red.svg', 'aktif'),
(4, 2, 'SPT-RUN-002', 'AirGlide Flex Cushion Blue', 'airglide-flex-cushion-blue', 'Sepatu olahraga
serbaguna dengan grip karet kuat untuk jogging, gym, maupun jalan santai. Desain gradasi biru elektrik
yang stylish.', '40, 41, 42, 43', 220000.00, 379000.00, 15, 5, 700, 'sepatu_running_blue.svg', 'aktif'),
(5, 3, 'SPT-FOR-001', 'Executive Oxford Leather Pantofel', 'executive-oxford-leather-pantofel',
'Sepatu pantofel pria model Oxford dengan kilap mewah dan sol kayu-karet presisi. Pilihan sempurna
untuk profesional, eksekutif, dan acara formal.',
'39, 40, 41, 42, 43, 44', 320000.00, 550000.00, 12, 4, 1100, 'sepatu_formal_oxford.svg', 'aktif'),
(6, 4, 'SPT-BOT-001', 'Trekker Ranger Leather Boots Brown', 'trekker-ranger-leather-boots-brown',
'Boots tangguh warna cokelat tua dengan jahitan ganda kokoh dan sol bergerigi antiselip. Cocok untuk
pengendara motor dan aktivitas luar ruang.', '40, 41, 42, 43, 44', 350000.00, 599000.00, 8, 3, 1300,
'sepatu_boots_brown.svg', 'aktif'),
(7, 5, 'SPT-SLP-001', 'Comfort Loafers Suede Navy', 'comfort-loafers-suede-navy',
'Sepatu slip-on loafers bahan suede lembut warna biru dongker dengan insole empuk Memory Foam untuk
kenyamanan maksimal kaki Anda.', '39, 40, 41, 42', 170000.00, 275000.00, 20, 5, 750,
'sepatu_loafers_navy.svg', 'aktif'),
(8, 1, 'SPT-SNK-003', 'Retro Runner Vintage Green', 'retro-runner-vintage-green',
'Kombinasi material suede dan nilon bergaya retro era 90-an warna hijau zaitun.
Sangat modis dipadukan dengan celana jeans atau chino.',
'39, 40, 41, 42, 43', 200000.00, 329000.00, 4, 5, 850, 'sepatu_retro_green.svg', 'aktif');

-- 4. Data Master Bagan Akun (Chart of Accounts / COA)
INSERT INTO `akun_rekening` (`kode_akun`, `nama_akun`, `kelompok_akun`, `posisi_normal`, `saldo_awal`)
VALUES
('101', 'Kas di Tangan / Kas Toko', 'Aset', 'Debit', 10000000.00),
('102', 'Kas di Bank (Rekening Utama)', 'Aset', 'Debit', 25000000.00),
('103', 'Piutang Usaha (COD / Marketplace)', 'Aset', 'Debit', 0.00),
('104', 'Persediaan Barang Dagang (Sepatu)', 'Aset', 'Debit', 28540000.00),
('201', 'Utang Usaha (Pemasok Sepatu)', 'Kewajiban', 'Kredit', 0.00),
('301', 'Modal Pemilik', 'Ekuitas', 'Kredit', 63540000.00),
('401', 'Pendapatan Penjualan Sepatu', 'Pendapatan', 'Kredit', 0.00),
('501', 'Beban Pokok Penjualan (HPP)', 'Beban_Pokok', 'Debit', 0.00),
('601', 'Beban Operasional & Pengiriman', 'Beban_Operasional', 'Debit', 0.00),
('602', 'Beban Listrik, Internet & Utilitas', 'Beban_Operasional', 'Debit', 0.00),
('603', 'Beban Promosi & Iklan Digital', 'Beban_Operasional', 'Debit', 0.00);

-- 5. Data Transaksi Sampel Pesanan (Untuk Dashboard Awal)
INSERT INTO `pesanan` (`id`, `no_pesanan`, `pengguna_id`, `tanggal_pesanan`, `total_belanja`, `ongkir`,
`total_bayar`, `status_pesanan`, `status_pembayaran`, `metode_pembayaran`, `kurir`, `nomor_resi`,
`nama_penerima`, `no_telp_penerima`, `alamat_pengiriman`, `catatan`) VALUES
(1, 'ORD-20260901-001', 4, '2026-09-01 10:30:00', 648000.00, 20000.00, 668000.00, 'selesai', 'lunas',
'transfer_bank', 'JNE Regular', 'JNE8899112233', 'Budi Santoso', '085677889900', 'Jl. Merdeka No. 45,
Bandung, Jawa Barat', 'Packing bubble wrap ganda'),
(2, 'ORD-20260905-002', 5, '2026-09-05 14:15:00', 425000.00, 15000.00, 440000.00, 'diproses', 'lunas',
'transfer_bank', 'SiCepat BEST', NULL, 'Siti Rahma', '087812345678', 'Jl. Malioboro No. 12, Yogyakarta',
'Warna tali cadangan jika ada'),
(3, 'ORD-20260910-003', 4, '2026-09-10 09:00:00', 299000.00, 10000.00, 309000.00, 'menunggu_pembayaran',
'belum_lunas', 'transfer_bank', 'J&T Express', NULL, 'Budi Santoso', '085677889900', 'Jl. Merdeka No. 45,
Bandung, Jawa Barat', 'Segera kirim');

-- 6. Data Detail Pesanan Sampel
INSERT INTO `detail_pesanan` (`id`, `pesanan_id`, `produk_id`, `ukuran_dipilih`, `kuantitas`,
`harga_satuan`, `hpp_satuan`, `subtotal`) VALUES
(1, 1, 1, '42', 1, 299000.00, 180000.00, 299000.00),
(2, 1, 2, '41', 1, 349000.00, 210000.00, 349000.00),
(3, 2, 3, '40', 1, 425000.00, 250000.00, 425000.00),
(4, 3, 1, '41', 1, 299000.00, 180000.00, 299000.00);

-- 7. Data Riwayat Mutasi Stok Sampel
INSERT INTO `mutasi_stok` (`id`, `produk_id`, `jenis_mutasi`, `jumlah`, `stok_sebelum`, `stok_sesudah`,
`nomor_referensi`, `keterangan`, `tanggal`, `pengguna_id`) VALUES
(1, 1, 'masuk_restock', 26, 0, 26, 'PO-SUPP-001', 'Penerimaan Stok Awal dari Pabrik Sepatu Bandung',
'2026-08-25 08:00:00', 1),
(2, 1, 'keluar_penjualan', -1, 26, 25, 'ORD-20260901-001', 'Pengurangan stok untuk pesanan Budi Santoso',
'2026-09-01 10:35:00', 1),
(3, 2, 'masuk_restock', 19, 0, 19, 'PO-SUPP-001', 'Penerimaan Stok Awal dari Pabrik Sepatu Bandung',
'2026-08-25 08:00:00', 1),
(4, 2, 'keluar_penjualan', -1, 19, 18, 'ORD-20260901-001', 'Pengurangan stok untuk pesanan Budi Santoso',
'2026-09-01 10:35:00', 1),
(5, 3, 'masuk_restock', 31, 0, 31, 'PO-SUPP-002', 'Penerimaan Stok Sepatu Lari HyperPulse',
'2026-08-28 09:00:00', 2),
(6, 3, 'keluar_penjualan', -1, 31, 30, 'ORD-20260905-002', 'Pengurangan stok untuk pesanan Siti Rahma',
'2026-09-05 14:20:00', 3);

-- 8. Data Jurnal Umum Keuangan Sampel (Double-Entry Balance)
-- Transaksi 1: Penjualan Pesanan ORD-20260901-001 Lunas
-- Debit Kas di Bank Rp 668.000, Kredit Pendapatan Penjualan Rp 648.000, Kredit Pendapatan Ongkir/Kas
Rp 20.000 (atau Pendapatan Total)
INSERT INTO `jurnal_keuangan` (`no_jurnal`, `tanggal`, `kode_akun`, `debit`, `kredit`, `keterangan`,
`referensi_transaksi`, `pengguna_id`) VALUES
('JRN-20260901-001', '2026-09-01', '102', 648000.00, 0.00,
'Penerimaan Kas Penjualan Sepatu ORD-20260901-001', 'ORD-20260901-001', 3),
('JRN-20260901-001', '2026-09-01', '401', 0.00, 648000.00,
'Pendapatan Penjualan Sepatu ORD-20260901-001', 'ORD-20260901-001', 3),
-- Jurnal HPP & Persediaan untuk ORD-20260901-001 (HPP: 180rb + 210rb = 390rb)
('JRN-20260901-002', '2026-09-01', '501', 390000.00, 0.00,
'Pengakuan HPP Beban Pokok Penjualan ORD-20260901-001', 'ORD-20260901-001', 3),
('JRN-20260901-002', '2026-09-01', '104', 0.00, 390000.00,
'Pengurangan Nilai Persediaan Barang Dagang ORD-20260901-001', 'ORD-20260901-001', 3),

-- Transaksi 2: Penjualan Pesanan ORD-20260905-002 Lunas
('JRN-20260905-001', '2026-09-05', '102', 425000.00, 0.00,
'Penerimaan Kas Penjualan Sepatu ORD-20260905-002', 'ORD-20260905-002', 3),
('JRN-20260905-001', '2026-09-05', '401', 0.00, 425000.00,
'Pendapatan Penjualan Sepatu ORD-20260905-002', 'ORD-20260905-002', 3),
-- Jurnal HPP ORD-20260905-002 (HPP: 250rb)
('JRN-20260905-002', '2026-09-05', '501', 250000.00, 0.00,
'Pengakuan HPP Beban Pokok Penjualan ORD-20260905-002', 'ORD-20260905-002', 3),
('JRN-20260905-002', '2026-09-05', '104', 0.00, 250000.00,
'Pengurangan Nilai Persediaan Barang Dagang ORD-20260905-002', 'ORD-20260905-002', 3),

-- Transaksi 3: Pembayaran Beban Listrik & Internet Toko
('JRN-20260908-001', '2026-09-08', '602', 450000.00, 0.00,
'Pembayaran Tagihan Listrik & Internet Kantor Bulan September', 'BBN-OPR-001', 1),
('JRN-20260908-001', '2026-09-08', '101', 0.00, 450000.00,
'Kas Toko Keluar untuk Listrik & Internet', 'BBN-OPR-001', 1);