<?php
require 'koneksi.php';
if(isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password']; // Ingat defaultnya 'password123'
    
    $query = mysqli_query($conn, "SELECT * FROM pengguna WHERE email='$email' AND status_aktif=1");
    if(mysqli_num_rows($query) > 0) {
        $data = mysqli_fetch_assoc($query);
        if(password_verify($password, $data['kata_sandi'])) {
            $_SESSION['user_id'] = $data['id'];
            $_SESSION['peran'] = $data['peran'];
            if($data['peran'] == 'pelanggan') { header("Location: index.php"); } 
            else { header("Location: admin_dashboard.php"); }
            exit;
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Email tidak ditemukan atau akun diblokir!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - Aeris Beaute</title>
    <style>
        body { font-family: 'Helvetica Neue', sans-serif; background-color: #1a1a1a; color: #fff; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-box { background: #2c1a1f; padding: 40px; border-radius: 8px; text-align: center; width: 100%; max-width: 400px; box-shadow: 0 4px 15px rgba(0,0,0,0.5); }
        .login-box img { width: 150px; margin-bottom: 20px; }
        input { width: 90%; padding: 12px; margin: 10px 0; border: 1px solid #555; background: #333; color: white; }
        button { width: 100%; padding: 15px; background: #e0b0b0; color: #000; font-weight: bold; border: none; cursor: pointer; text-transform: uppercase; }
        button:hover { background: #fff; }
    </style>
</head>
<body>
    <div class="login-box">
        <img src="/image/banner/logo.png" alt="AERIS BEAUTE">
        <h2>LOGIN PENGGUNA</h2>
        <?php if(isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <form method="POST">
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="login">Sign In</button>
        </form>
    </div>
</body>
</html>